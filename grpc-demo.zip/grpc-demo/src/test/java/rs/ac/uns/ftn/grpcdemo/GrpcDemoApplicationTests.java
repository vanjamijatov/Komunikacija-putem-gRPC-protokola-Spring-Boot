package rs.ac.uns.ftn.grpcdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpcDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
